package com.nycresistor.processing;

import processing.core.*;
import processing.net.*;
import processing.serial.*;

/**
 * Provides an interface onto a real or virtual SpookyBox device
 * @author justin
 */
public class SpookyBox {
	public static final int SERIAL = 1;
	public static final int NETWORK = 2;

	PApplet parent = null;
	Client client = null;
	Serial serial = null;
	byte[] buffer = new byte[128];
	
	int knob1 = 0;
	int knob2 = 0;
	int knob3 = 0;
	boolean button1 = false;
	boolean button2 = false;
	boolean button3 = false;
	boolean button4 = false;

	/**
	 * Connects to a SpookyBox and begins receiving data.
	 * @param parent The applet (this)
	 * @param method Either SpookyBox.SERIAL for serial connections, or SpookyBox.NETWORK for network connections
	 * @param serverOrSerialPort If using SERIAL, the name of the serial port to use.  If using NETWORK, the server address to use.
	 * @param serverPortOrBaudRate If using SERIAL, the baud rate to use.  If using NETWORK, the TCP port number to connect to.
	 */
	public SpookyBox(PApplet parent, int method, String serverOrSerialPort, int serverPortOrBaudRate) {
		this.parent = parent;
		
		if (method == SERIAL) {
			serial = new Serial(parent, serverOrSerialPort, serverPortOrBaudRate);
		}
		else {
			client = new Client(parent, serverOrSerialPort, serverPortOrBaudRate);
		}
		
		parent.registerDispose(this);
		parent.registerPre(this);				
	}
	
	/**
	 * Connects to a SpookyBox and begins receving data.   If the method given is SERIAL, the first SerialPort available will be tried at 9600 baud.
	 * If method given is NETWORK, the client will connect to localhost on port 5204.
	 * @param parent The applet (this)
	 * @param method Either SpookyBox.SERIAL for serial connections, or SpookyBox.NETWORK for network connections
	 */
	public SpookyBox(PApplet parent, int method) {
		this.parent = parent;
		
		if (method == SERIAL) {
			serial = new Serial(parent, Serial.list()[0], 9600);
		}
		else {
			client = new Client(parent, "localhost", 5204);
		}
		
		parent.registerDispose(this);
		parent.registerPre(this);		
	}
	
	/**
	 * Called when your applet closes to clean up.
	 */
	public void dispose() {
		if (client != null)
			client.stop();
		
		if (serial != null)
			serial.stop();
	}

	/**
	 * Returns the value of Knob 1
	 * @return A number between 0-1024
	 */
	public int getKnob1() {
		return knob1;
	}
	
	/**
	 * Returns the value of Knob 2
	 * @return A number between 0-1024
	 */
	public int getKnob2() {
		return knob2;
	}

	/**
	 * Returns the value of Knob 3
	 * @return A number between 0-1024
	 */
	public int getKnob3() {
		return knob3;
	}

	/**
	 * Returns true if button 1 is being pressed
	 * @return True if button is being pressed
	 */
	public boolean isButton1() {
		return button1;
	}

	/**
	 * Returns true if button 2 is being pressed
	 * @return True if button is being pressed
	 */
	public boolean isButton2() {
		return button2;
	}

	/**
	 * Returns true if button 3 is being pressed
	 * @return True if button is being pressed
	 */
	public boolean isButton3() {
		return button3;
	}

	/**
	 * Returns true if button 4 is being pressed
	 * @return True if button is being pressed
	 */
	public boolean isButton4() {
		return button4;
	}
	
	/**
	 * Called when entering a frame.  Checks for and reads any new data.
	 */
	public void pre() {
		parseData(readData());
	}

	/**
	 * Reads data from serial or network
	 * @return Number of bytes read
	 */
	private int readData() {
		if (client != null) {
			if (client.available() > 0) {
				return client.readBytes(buffer);
			}
		}
		else {
			if (serial.available() > 0) {
				return serial.readBytes(buffer);
			}
		}
		
		return 0;
	}
	
	/**
	 * Parses the data into usable information.
	 * @param bytesRead
	 */
	private void parseData(int bytesRead) {
		if (bytesRead > 0) {
			int dataOffset = findDataOffet(buffer,bytesRead);       
			if (dataOffset != -1) {
				knob1 = extractInt(buffer,dataOffset);
				knob2 = extractInt(buffer,dataOffset+2);
				knob3 = extractInt(buffer,dataOffset+4);
				button1 = extractBoolean(buffer,dataOffset+6);
				button2 = extractBoolean(buffer,dataOffset+7);
				button3 = extractBoolean(buffer,dataOffset+8);
				button4 = extractBoolean(buffer,dataOffset+9);
			}
		}
	}
			
	/**
	 * Finds the beginning of the data by looking for 3 bytes in a row that are 255.  Because the knobs can only read 0-1024
	 * and the buttons can only read 0-1 it should only be possible to get three 255's from this signiture.
	 * @param buffer
	 * @param bytes
	 * @return
	 */
	private int findDataOffet(byte[] buffer, int bytes) {
		int matches = 0;

		for (int i=0; i<bytes; i++) {
			if (buffer[i] == -1) {
				matches++;
			}
			else {
				matches = 0;
			}

			if (matches == 3) {
				if (bytes-i >= 10) {
					return i + 1;
				}
			}
		}

		return -1;
	}

	/**
	 * Extracts an integer from two bytes.  Assumes bytes are 16-bit big endian.
	 * @param buffer
	 * @param offset
	 * @return
	 */
	private int extractInt(byte[] buffer, int offset) {
		int result = buffer[offset] << 8;
		
		// Why oh why would you want to sign a byte?
		if (buffer[offset+1] < 0) {
			result += (buffer[offset+1] + 256);
		}
		else {
			result += buffer[offset+1];
		}

		return result;
	}

	/**
	 * Extracts a boolean from a single byte.
	 * @param buffer
	 * @param offset
	 * @return
	 */
	private boolean extractBoolean(byte[] buffer, int offset) {
		return buffer[offset] != 0;
	}
}
